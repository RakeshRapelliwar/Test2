/** Automatically generated file. DO NOT MODIFY */
package com.xabber.androiddev;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}